/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js}"],
    theme: {
      extend: {
        colors: {
          'one-blue': '#296BD5',
          'bg-one-blue': '#296BD5',
          'one-gray': '#252525',
          'one-white': '#FFFFFF',
  
        },
        height: {
          'h-90': '120%',
        },
         maxWidth: {
            'small-s': '2rem',
          'small-x': '9rem',
          'small-one': '10rem',
          'mobile-paragraphe': '16rem',
          'our-size': '18rem',
          'second-size': '31rem',
        },
        fontSize:{
         'reseller-size': '0.2rem',
         'mobile-reseller': '3rem',
         'base-x': '1.15rem',
  
        },
      },
      fontFamily: {
        'one': ['Montserrat', 'Georgia']
      },
      fontSize:{
        xs: '0.75rem',
        sm: '0.8rem',
        base: '1rem',
        lg:  '1.125rem',
        xl: '1.25rem',
        '2xl': '1.563rem',
        '3xl': '1.953rem',
        '4xl': '2.441rem',
        '5xl': '2.6rem',
        '6xl': '3.5rem',
        '7xl': '3.75rem',
        '8xl': '6rem',
        '9xl': '8rem',
        
      }
    },
  
    plugins: [],
  }