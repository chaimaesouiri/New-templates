/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js}"],
    theme: {
      extend: {
        fontFamily: {
          'noto-sans-jp': ['Noto Sans JP', 'sans-serif'],
        },
        colors: {
          'arow-blue':'#175CFF',
          't-x-t-p':'#02084d',
          'yellow-sub':'#fff301',
          'para-sub':'#312f2f',
          'submit-drk-title':'#2a2d2e',
          'divider-purple':'#6528f7',
          'submit-black':'#0c0c0c',
          'dark-blog':'#01074a',
          'gray-blog':'#777;',
          'flash':'#00ffff',
          'small-p':'#000000fa',
          'grande-titre':'#02094e',
          'text-saas-drk':'#020848',
          'clear-sass-blue':'#C7CEFF',
          'dark-sass':'#03094f',
          'sass-blue':'#3C00C9',
          'one-blue': '#296BD5',
          'bg-one-blue': '#296BD5',
          'one-gray': '#252525',
          'one-white': '#FFFFFF',
          'bg-price':'#EFEFEF',
          'green-t':'#12BF7C',
          'green-button':'#026D44',
          'white-body':'#fbfcfc',
          'orange-red':'#ff6154',
          'our-black':'#1768af',
          'sky-blue':'#e7f9f2',
          'whit-t':'#F5F5F5',
          'gray-m':'#7E8181',
          'purpl-nav':'#9966FF',
          'twinr-black':'#1B1B1B',
          'green-the':'#171D1B',
          'geen-add':'#B4E8D4',
          'button-nav':'#0A2540',
          'black-gradient':'#232139',
          'red-gradient':'#BC1010',
          'red-2-gradient':'#9D0F0F',
          'clear-blue':'#F4F8FB',
          'bg-dark':'#0A2540',
          'gray-button':'#d5d5d6',
          'gray-blue':'#ADBBC3',
          'bg-footer':'#072137',
           'ligne-gray':'#cdcdd0',
           'li-price':'#0a243e',
           'g':'#525255',
           'place-black':'#1c1c1c', 
           'gray-li':'#616574',
            'gray-first':'#B2AFB8',
            'dark-bt':'#0D122A',
            'green-mumbler':'#00E78E',
            'blue-a':'#0A7BD8',
            'gray-sub':'#928C9B',
            'green-blog':'#69FAA1',
            'gray-title':'#9894A1',
            'green-ground':'#02BA70',
             'blue-facebook':'#406FD8',

          
  
        },
        height: {
          'h-90': '120%',
        },
         maxWidth: {
            'small-s': '2rem',
          'small-x': '9rem',
          'small-one': '10rem',
          'small-small':'13rem',
          'mobile-paragraphe': '16rem',
          'our-size': '18rem',
          'second-size': '31rem',
        },
        fontSize:{
         'reseller-size': '0.2rem',
         'mobile-reseller': '3rem',
         'base-x': '1.15rem',
  
        },
        darkMode: 'class',
        // ...
      
      },
      fontFamily: {
        'one': ['Montserrat', 'Georgia']
      },
      fontSize:{
        xs: '0.75rem',
        sm: '0.8rem',
        base: '1rem',
        lg:  '1.125rem',
        xl: '1.25rem',
        '2xl': '1.563rem',
        '3xl': '1.953rem',
        '4xl': '2.441rem',
        '5xl': '2.6rem',
        '6xl': '3.5rem',
        '7xl': '3.75rem',
        '8xl': '6rem',
        '9xl': '8rem',
        
      }
    },
  
    plugins: [],
  }