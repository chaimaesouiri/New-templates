// Get all elements with the class 'dynamic-word'
var dynamicWordElements = document.querySelectorAll('.dynamic-word');

// Your dynamic word
var dynamicWord = 'Twinr';

// Change the content of each element
dynamicWordElements.forEach(function(element) {
    element.textContent = element.textContent.replace('static', dynamicWord);
});