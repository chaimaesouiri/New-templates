module.exports = process.env.NODE_ENV === 'production' ? require('./build/mocks') : require('./build');

