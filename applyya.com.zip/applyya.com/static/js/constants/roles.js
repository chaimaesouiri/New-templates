export const ROLE_USER = 'user-role';
export const ROLE_ADMIN = 'admin-role';
